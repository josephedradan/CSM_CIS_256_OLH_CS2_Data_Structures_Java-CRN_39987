//package StandardAnimation;
//
//import javafx.animation.SequentialTransition;
//
//// Base of Every FXGraph.FXAnimation
//abstract class FXAnimation {
//
//    protected SequentialTransition sequentialTransition;
//
//    public SequentialTransition getSequentialTransitionChangeTimeBased() {
//        return sequentialTransition;
//    }
//
//    protected abstract void createSequentialTransition(double initialTime);
//}
