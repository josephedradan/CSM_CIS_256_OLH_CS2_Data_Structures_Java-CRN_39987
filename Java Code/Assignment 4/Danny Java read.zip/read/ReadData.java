import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;

public class ReadData {

    private static int VERTEX_SIZE = 0; // number of vertices
    private static int EDGE_SIZE = 0; // number of edges

    public static void main(String[] args)  {
        System.out.println("File entries to read for finding longest path:\n");


        String errorMessage = "\nYou have not selected a valid option."
            + "\nSelect either file number \"1\" or file number \"2\""
            + "\nor file number \"3\" or file number \"4\""
            +  "or enter \"0\" to quit: ";

        File[] fileList = new File(".").listFiles((dir, name) -> name.endsWith(".txt"));
        ArrayList<String> fileSelection = new ArrayList<>();
        ArrayList<Integer> fileNumberSelection = new ArrayList<>();
      
        // FileFilter selectOnlyTextFiles = newWildcardFileFilter("*.txt", IOCase.INSENSITIVE);
        int fileCounter = 0;
        for (int i = 0; i < fileList.length; i++){
            fileSelection.add(fileList[i].getName());
            fileNumberSelection.add(++fileCounter);
        }
        int userSelection = 0;
        String filename = null;
        

        do { 
            Scanner readUserInput = null;   

            for (int j = 0; j < fileList.length; j++){
                System.out.println("File #" + fileNumberSelection.get(j) + ": " + fileSelection.get(j)); 
            }

            System.out.println("\nTotal text files to test: " + fileCounter);
            System.out.println("Which file would you like to choose:");
            System.out.print("(select file number or select \"0\" to quit): ");

            try {

                readUserInput = new Scanner(System.in);
                userSelection = readUserInput.nextInt();

                if (userSelection == 0){
                    System.out.println("\nProgram has exited successfully!\n");
                    readUserInput.close();
                    System.exit(0);
                }


                if (userSelection == fileNumberSelection.get(userSelection - 1)){
                    System.out.println("\nFile number " + userSelection + " is the correct file number chosen\n");
                    filename = fileSelection.get(userSelection - 1);

                } else {
                    throw new WrongInputException("\"" + userSelection + "\" is not the correct file chosen!\n");
                }

            } catch (NumberFormatException ex){
                System.out.println(ex.getMessage());
                System.out.println(errorMessage);
            } catch (IndexOutOfBoundsException iob){
                System.out.println(errorMessage);
                System.err.println(iob.getMessage());
            } catch (WrongInputException wie){
                System.out.println(errorMessage);
                System.err.println(wie.getMessage());
            } catch (InputMismatchException ime){
                System.err.println(ime.getMessage());
                System.out.println(errorMessage);
            } catch (NoSuchElementException nse){
                System.err.println(nse.getMessage());
                System.out.println(errorMessage);
            }

            BufferedReader reader = null;
            String read = null;
            List<String> entryList = new ArrayList<String>();  

            if (filename != null){
                try {
                  
                    reader = new  BufferedReader (new FileReader (filename));  
                    VERTEX_SIZE = Integer.parseInt(reader.readLine());
                    EDGE_SIZE = Integer.parseInt(reader.readLine());
                    int entryCount = 0; // count number of entries
                    int startingVertex = 0;
                    int endingVertex = 0;
                    int edgeLength = 0;
                    String edgeName = "";

                    System.out.println("File name chosen: " + filename);
                    System.out.println("------------------------------------------------------------------------");
                    System.out.println("Total number of vertices: " + VERTEX_SIZE);
                    System.out.println("Total number of edges: " + EDGE_SIZE);

                    while ((read = reader.readLine()) != null) { 
                        String[] splitLines = read.split("\\n");
                        String[] splitCommas = splitLines[0].split(",");
                            
                        startingVertex = Integer.parseInt(splitCommas[0]);
                        endingVertex = Integer.parseInt(splitCommas[1]);
                        edgeLength = Integer.parseInt(splitCommas[2]);
                        edgeName = splitCommas[3];

                        System.out.println("Starting vertex: " + startingVertex + ", ending vertex: "
                            + endingVertex + ", edge length: " + edgeLength + ", edge name: " + edgeName);

                        entryList.add(splitLines[0]);
                        entryCount++; 
                    }
                    System.out.println("------------------------------------------------------------------------\n");

                } catch (FileNotFoundException fe){
                    System.out.println("The file " + filename + " was not found.");
                    fe.printStackTrace();
                } catch (IOException ioe){
                    ioe.printStackTrace();
                } finally {
                    try {
                        if (reader != null){
                            reader.close();
                            entryList.clear();
                        }
                    } catch (IOException ie){
                        ie.printStackTrace();
                    }
                }
            } 
        } while (userSelection  != 0 || filename == null); // continue running program if this condition is met
    }
}










